JANVI WATERPROOFING SOLUTIONS - FREE WEBSITE

1. Open index.html to preview the website.
2. Before publishing, replace +91XXXXXXXXXX in index.html with the real business WhatsApp/phone number.
3. You can publish the site free using a static hosting service such as GitHub Pages or Netlify's free tier.
